import { ListItemAvatar,List,Input,ListItem,FormControl,ListItemText,IconButton,Button} from '@material-ui/core'
import React from 'react'
import db from "./Firebase"
import { Delete } from '@material-ui/icons'
import Modal from '@material-ui/core/Modal';
import { makeStyles } from '@material-ui/core/styles';
import EditIcon from '@material-ui/icons/Edit';
import "./App.css"

  
function getModalStyle() {
const top = 50 ;
const left = 50 ;

return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
};
}

const useStyles = makeStyles((theme) => ({
    paper: {
      position: 'absolute',
      width: 400,
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
    },
}));

const Todo = (props) => {

    const classes = useStyles();
    const [modalStyle] = React.useState(getModalStyle);
    const [open, setOpen] = React.useState(false);
    const [input, setInput] = React.useState();

    const handleOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    const updatetodo = () => {
        db.collection("todo").doc(props.id).set({
           todo : input
        },{merge:true});
        setOpen(false)
    }

    return (
        <>
        <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="simple-modal-title"
            aria-describedby="simple-modal-description"
        >
            <div style={modalStyle} className={classes.paper}>
                <h1>{props.text}</h1>
                <FormControl>
                <Input autoFocus={true} value={input} placeholder={props.text} onChange={(e)=>{return setInput(e.target.value)}}/><br/>
                <Button variant="outlined" style={{outline:"none"}} color="secondary" disabled={!input} onClick={updatetodo}>Update</Button>
                </FormControl>
            </div>
        </Modal>

        <List>
            <ListItem>
            <ListItemAvatar>
            </ListItemAvatar>
                <ListItemText key={props.id} primary={props.no + 1} secondary={props.text}/>
                <IconButton className="text-info" style={{outline:"none"}} onClick={handleOpen}><EditIcon/></IconButton>
                <IconButton className="text-danger" style={{outline:"none"}} onClick={e => {db.collection("todo").doc(props.id).delete()}}><Delete/></IconButton>
            </ListItem>
        </List>
        </>
    )
}

export default Todo
