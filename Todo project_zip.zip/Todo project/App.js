import React, { useEffect, useState } from 'react'
import "./App.css"
import Button from '@material-ui/core/Button';
import { FormControl,Input,FormHelperText,InputLabel } from '@material-ui/core';
import Todo from './Todo';
import db from "./Firebase";
import firebase from "firebase";


const App = () => {

    const [todo,setTodo] = useState([]);
    const [input,setInput] = useState();
   
    const addtodo = (e) => {
        e.preventDefault();
        db.collection('todo').add({
            todo : input,
            timestamp : firebase.firestore.FieldValue.serverTimestamp()
        })
        setInput("");
    }

    useEffect(() => {
     
       db.collection("todo").orderBy('timestamp','desc').onSnapshot(snapshot => {
           setTodo(snapshot.docs.map(doc => ({id:doc.id,todo:doc.data().todo})))
       })
    },[])

    return (
        <>
        <div className="App">
            <h2 className="alert-info">ToDo Project</h2><br/>
            
            <form>
            <FormControl>
                <InputLabel>Add Item</InputLabel>
                <Input autoFocus={true} placeholder="Enter Item" value={input} onChange={(e)=>{return setInput(e.target.value)}}/>
                <FormHelperText id="my-helper-text">We'll never share your detail.</FormHelperText>
            </FormControl>

            <Button disabled={!input} type="submit" onClick={addtodo} style={{outline:"none"}} variant="contained" color="primary">
                Add Item
            </Button>
            </form>

            {todo.map((item,id) => {return <Todo text={item.todo} no={id} id={item.id}/>})}

                    
        </div>
        </>
    )
}

export default App;